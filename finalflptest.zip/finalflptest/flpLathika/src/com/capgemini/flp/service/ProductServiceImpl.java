package com.capgemini.flp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;




import com.capgemini.flp.dao.IProductDao;
import com.capgemini.flp.dto.Admin;
import com.capgemini.flp.dto.Customer;
import com.capgemini.flp.dto.Merchant;
import com.capgemini.flp.exception.ProductException;

@javax.transaction.Transactional
@Service
public class ProductServiceImpl implements IProductService {
	
	@Autowired
	IProductDao products;

	@Override
	public List<Admin> getProducts() throws ProductException {
		return products.getProducts();
	}

	@Override
	public List<Admin> getProductsBasedOnCategory(String name) throws ProductException {
		
		return products.getProductsBasedOnCategory(name);
	}

	@Override
	public String updateCustomer(Customer c) throws ProductException {
		// TODO Auto-generated method stub
		return products.updateCustomer(c);
	}

	@Override
	public String updateMerchant(Merchant m) throws ProductException {
		// TODO Auto-generated method stub
		return products.updateMerchant(m);
	}

}
