package com.capgemini.flp.dao;

import java.util.List;

import com.capgemini.flp.dto.Admin;
import com.capgemini.flp.dto.Customer;
import com.capgemini.flp.dto.Merchant;
import com.capgemini.flp.exception.ProductException;

public interface IProductDao {
	
	public List<Admin> getProducts() throws ProductException;
	
	public List<Admin> getProductsBasedOnCategory(String name) throws ProductException;

	public String updateCustomer(Customer c)throws ProductException;

	public String updateMerchant(Merchant m) throws ProductException;

}
