package com.capgemini.flp.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.flp.dto.Admin;
import com.capgemini.flp.dto.Customer;
import com.capgemini.flp.dto.Merchant;
import com.capgemini.flp.exception.ProductException;

@Repository
public class ProductDaoImpl implements IProductDao {

	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public List<Admin> getProducts() throws ProductException {
		try{
			TypedQuery<Admin> query=entityManager.createQuery("from Admin",Admin.class);
			return query.getResultList();
			}catch(Exception e){
				throw new ProductException(e.getMessage());
			}
	}

	@Override
	public List<Admin> getProductsBasedOnCategory(String name) throws ProductException {
		try{
			TypedQuery<Admin> query=entityManager.createQuery("select admin from Admin admin where admin.productCategory=:name",Admin.class).setParameter("name", name);
			return query.getResultList();
			}catch(Exception e){
				throw new ProductException(e.getMessage());
			}
	}

	@Override
	public String updateCustomer(Customer c) throws ProductException {
		String status="";
		try{
			Customer c1= entityManager.find(Customer.class, c.getEmailId());
			if(c1 != null){
				if(!c.getName().equals("")){
					c1.setName(c.getName());
				}
				if(c.getPhoneNumber() !=null){
					c1.setPhoneNumber(c.getPhoneNumber());
				}
				if(!c.getAddress().equals("")){
					c1.setAddress(c.getAddress());
				}
				entityManager.merge(c1);
				status="Customer Info Updated";
			}else{
				status="Account Not Found";
			}	
		}catch(Exception e){
			throw new ProductException(e.getMessage());
		}
		return status;
	}

	@Override
	public String updateMerchant(Merchant m) throws ProductException {
		String status="";
		try{
			Merchant m1= entityManager.find(Merchant.class, m.getEmailId());
			if(m1 != null){
				if(!m.getName().equals("")){
					m1.setName(m.getName());
				}
				if(m.getPhoneNumber() !=null){
					m1.setPhoneNumber(m.getPhoneNumber());
				}
				if(!m.getAddress().equals("")){
					m1.setAddress(m.getAddress());
				}
				
				entityManager.merge(m1);
				status="Merchant Info Updated";
			}else{
				status="Account Not Found";
			}
		}catch(Exception e){
			throw new ProductException(e.getMessage());
		}
		return status;
	}

}
