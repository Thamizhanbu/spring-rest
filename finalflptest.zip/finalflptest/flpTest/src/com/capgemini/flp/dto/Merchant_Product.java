package com.capgemini.flp.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Merchant_Product")
public class Merchant_Product {
	
	@Id
	@Column(name="product_Id")
	private int productId;
	@Column(name="product_Name")
	private String productName;
	@Column(name="product_Category")
	private String productCategory;
	@Column(name="product_Description")
	private String productDescription;
	@Column(name="product_Price")
	private double productPrice;
	@Column(name="product_Image")
	private String productImage;
	@Column(name="product_Quantity")
	private long productQuantity;
	@Column(name="seller_email_Id")
	private String sellerEmailId;
	@Column(name="product_Discount")
	private int productDiscount;
	private int timeForDiscount;
	private String productPromo;
	private int timeForPromo;
	private long numberOfProductSold;
	private long numberOfProductExchanged;
	private double sellingAmount;
	private double exchangeAmount;
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductCategory() {
		return productCategory;
	}
	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}
	public String getProductDescription() {
		return productDescription;
	}
	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}
	public double getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(double productPrice) {
		this.productPrice = productPrice;
	}
	public String getProductImage() {
		return productImage;
	}
	public void setProductImage(String productImage) {
		this.productImage = productImage;
	}
	public long getProductQuantity() {
		return productQuantity;
	}
	public void setProductQuantity(long productQuantity) {
		this.productQuantity = productQuantity;
	}
	public String getSellerEmailId() {
		return sellerEmailId;
	}
	public void setSellerEmailId(String sellerEmailId) {
		this.sellerEmailId = sellerEmailId;
	}
	public int getProductDiscount() {
		return productDiscount;
	}
	public void setProductDiscount(int productDiscount) {
		this.productDiscount = productDiscount;
	}
	public String getProductPromo() {
		return productPromo;
	}
	public void setProductPromo(String productPromo) {
		this.productPromo = productPromo;
	}
	public long getNumberOfProductSold() {
		return numberOfProductSold;
	}
	public void setNumberOfProductSold(long numberOfProductSold) {
		this.numberOfProductSold = numberOfProductSold;
	}
	public long getNumberOfProductExchanged() {
		return numberOfProductExchanged;
	}
	public void setNumberOfProductExchanged(long numberOfProductExchanged) {
		this.numberOfProductExchanged = numberOfProductExchanged;
	}
	public double getSellingAmount() {
		return sellingAmount;
	}
	public void setSellingAmount(double sellingAmount) {
		this.sellingAmount = sellingAmount;
	}
	public double getExchangeAmount() {
		return exchangeAmount;
	}
	public void setExchangeAmount(double exchangeAmount) {
		this.exchangeAmount = exchangeAmount;
	}
	public int getTimeForDiscount() {
		return timeForDiscount;
	}
	public void setTimeForDiscount(int timeForDiscount) {
		this.timeForDiscount = timeForDiscount;
	}
	public int getTimeForPromo() {
		return timeForPromo;
	}
	public void setTimeForPromo(int timeForPromo) {
		this.timeForPromo = timeForPromo;
	}
	

}
