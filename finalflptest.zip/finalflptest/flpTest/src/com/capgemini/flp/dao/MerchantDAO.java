package com.capgemini.flp.dao;

import org.springframework.data.jpa.repository.JpaRepository; 
import org.springframework.data.jpa.repository.Query;

import com.capgemini.flp.dto.Merchant;

public interface MerchantDAO extends JpaRepository<Merchant, Integer>{
	
	@Query("select m from Merchants m where m.emailId=?1 ")
	Merchant findMerchant(String emailId);
	
	
	@Query("delete from Merchants m where m.emailId = ?1")
	void deleteMerchant(String emailId);
}
