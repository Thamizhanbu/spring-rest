package com.capgemini.flp.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.flp.dto.Merchant_Product;
import com.capgemini.flp.exception.ProductException;

@Repository
public class ProductDaoImpl implements IProductDao {

	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public List<Merchant_Product> getProducts() throws ProductException {
		try{
			TypedQuery<Merchant_Product> query=entityManager.createQuery("from Admin",Merchant_Product.class);
			return query.getResultList();
			}catch(Exception e){
				throw new ProductException(e.getMessage());
			}
	}

	@Override
	public List<Merchant_Product> getElectronicProducts() throws ProductException {
		try{
			TypedQuery<Merchant_Product> query=entityManager.createQuery("select admin from Admin admin where admin.productCategory='Electronics'",Merchant_Product.class);
			return query.getResultList();
			}catch(Exception e){
				throw new ProductException(e.getMessage());
			}
	}

	@Override
	public List<Merchant_Product> getFashionProducts() throws ProductException {
		try{
			TypedQuery<Merchant_Product> query=entityManager.createQuery("select admin from Admin admin where admin.productCategory='Fashion' or admin.productCategory='fashion' ",Merchant_Product.class);
			return query.getResultList();
			}catch(Exception e){
				throw new ProductException(e.getMessage());
			}
	}

	@Override
	public List<Merchant_Product> getFurnitureProducts() throws ProductException {
		try{
			TypedQuery<Merchant_Product> query=entityManager.createQuery("select admin from Admin admin where admin.productCategory='Furniture' or admin.productCategory='furniture' ",Merchant_Product.class);
			return query.getResultList();
			}catch(Exception e){
				throw new ProductException(e.getMessage());
			}
	}

	@Override
	public List<Merchant_Product> getSportsBooksAndMoreProducts() throws ProductException {
		try{
			TypedQuery<Merchant_Product> query=entityManager.createQuery("select admin from Admin admin where admin.productCategory='sports' or admin.productCategory='books' or admin.productCategory='more' ",Merchant_Product.class);
			System.out.println("jdhygfi");
			return query.getResultList();
			}catch(Exception e){
				throw new ProductException(e.getMessage());
			}
	}

	@Override
	public Merchant_Product getProduct(String product) throws ProductException {
		try{
			TypedQuery<Merchant_Product> query=entityManager.createQuery("select admin from Admin admin where admin.productName='"+product+"'",Merchant_Product.class);
			return query.getSingleResult();
			}catch(Exception e){
				throw new ProductException(e.getMessage());
			}
	}

	@Override
	public List<Merchant_Product> getProductsAsc(String name) throws ProductException {
	
		try{
			TypedQuery<Merchant_Product> query=entityManager.createQuery("select admin from Admin admin where admin.productCategory='"+name+"' order by admin.productPrice ASC",Merchant_Product.class);
			return query.getResultList();
			}catch(Exception e){
				throw new ProductException(e.getMessage());
			}
	}

	@Override
	public List<Merchant_Product> getProductDesc(String category) throws ProductException {
          
		try{
			TypedQuery<Merchant_Product> query=entityManager.createQuery("select admin from Admin admin where admin.productCategory='"+category+"' order by admin.productPrice DESC",Merchant_Product.class);
			return query.getResultList();
			}catch(Exception e){
				throw new ProductException(e.getMessage());
			}
	}

	@Override
	public Merchant_Product getProductDetails(int id) throws ProductException {
		try{
			TypedQuery<Merchant_Product> query=entityManager.createQuery("select admin.productQuantity from Admin admin where admin.productId='"+id+"' ",Merchant_Product.class);
			System.out.println("hi");
			return query.getSingleResult();
			}catch(Exception e){
				throw new ProductException(e.getMessage());
			}
	}
	
}
