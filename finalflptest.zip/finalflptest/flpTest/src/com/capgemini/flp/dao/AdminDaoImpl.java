package com.capgemini.flp.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;



import com.capgemini.flp.dto.Customer;
import com.capgemini.flp.dto.Merchant;
import com.capgemini.flp.dto.Merchant_Product;
import com.capgemini.flp.exception.AllException;





@Repository
public class AdminDaoImpl implements IAdminDao {
	@PersistenceContext 
	EntityManager entityManager;
		
		
	

	





		@Override
		public List<Customer> getAllCustomerDetails() throws AllException {
			Query query=entityManager.createQuery("From Customer");
			List<Customer> customerList=query.getResultList();
			return customerList;
		}





		@Override
		public List<Merchant> getAllMerchantDetails() throws AllException {
			Query query=entityManager.createQuery("From Merchant");
			List<Merchant> merchantList=query.getResultList();
			return merchantList;
		}





		@Override
		public List<Merchant_Product> getAllproductDetails() throws AllException {
			System.out.println("hi");
		Query query=entityManager.createQuery("Select p From Merchant_Product p");
			List<Merchant_Product> productList=query.getResultList();
			return productList;
			
		}
		}


