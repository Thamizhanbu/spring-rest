package com.capgemini.flp.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.flp.exception.LoginException;
import com.capgemini.flp.dto.Admin;
import com.capgemini.flp.dto.Merchant;
import com.capgemini.flp.dto.Customer;
import com.capgemini.flp.service.ILoginService;


@Controller
public class LoginController {
	
	@Autowired
	private ILoginService service;
	
	@RequestMapping(value="/userlogin")
	public ModelAndView userLoginPage() {
		return new ModelAndView("userLogin","user",new Customer());
	}
	
	@RequestMapping(value="/adminlogin")
	public ModelAndView adminLogin() {
		return new ModelAndView("adminLogin","admin",new Admin());
	}
	
	@RequestMapping(value="/merchantlogin")
	public ModelAndView viewLogin() {
		return new ModelAndView("merchantLogin","merchant",new Merchant());
	}
	
	
/*	@RequestMapping(value="/verifyuser", method=RequestMethod.POST)
	public ModelAndView doLogin( @Valid @ModelAttribute("user") UserLogin user,
			HttpServletRequest request, Model model){
		ModelAndView mv=null;
		System.out.println("ABABABA");
		try {
				System.out.println("BBBBB");
				if(isValidUserCredential(user.getEmailId(),user.getPassword())) {
					System.err.println("valid part");
					HttpSession session= request.getSession();
					session.setAttribute("emailId", user.getEmailId());
					
					mv= new ModelAndView("main_menu", "message", session.getAttribute("emailId"));
				}else{
					
					mv= new ModelAndView("main_menu", "message", "not success");
				}
			
		} catch (Exception e) {			
			e.printStackTrace();
		}		
		
		return mv;
	}*/
	
	@RequestMapping(value="/verifyuser", method=RequestMethod.POST)
	public ModelAndView doLogin( @Valid @ModelAttribute("user") Customer customer,
			HttpServletRequest request, Model model){
		ModelAndView mv=null;
		try {
		
				if(isValidUserCredential(customer.getEmailId(),customer.getPassword())) 
				{
					System.err.println("valid part");
					HttpSession session= request.getSession();
					session.setAttribute("emailId", customer.getEmailId());
					
					mv= new ModelAndView("usermenu", "message", session.getAttribute("emailId"));
				}else{
					
					mv= new ModelAndView("main_menu", "message", "not success");
				}
			
		} catch (Exception e) {			
			e.printStackTrace();
		}		
		
		return mv;
	}
	@RequestMapping(value="/verifyadmin", method=RequestMethod.POST)
	public ModelAndView doLogin( @Valid @ModelAttribute("admin") Admin user,
			HttpServletRequest request, Model model){
		ModelAndView mv=null;
		try {
		
				if(isValidAdminCredential(user.getEmailId(),user.getPassword())) {
					System.err.println("valid part");
					HttpSession session= request.getSession();
					session.setAttribute("emailId", user.getEmailId());
					
					mv= new ModelAndView("adminmenu", "message", session.getAttribute("emailId"));
				}else{
					
					mv= new ModelAndView("main_menu", "message", "not success");
				}
			
		} catch (Exception e) {			
			e.printStackTrace();
		}		
		
		return mv;
	}

	@RequestMapping(value="/verifymerchant", method=RequestMethod.POST)
	public ModelAndView doLogin( @Valid @ModelAttribute("merchant") Merchant user,
			HttpServletRequest request, Model model){
		ModelAndView mv=null;
		try {
		
				if(isValidMerchantCredential(user.getEmailId(),user.getPassword())) {
					System.err.println("valid part");
					HttpSession session= request.getSession();
					session.setAttribute("emailId", user.getEmailId());
					
					mv= new ModelAndView("merchantmenu", "message", session.getAttribute("emailId"));
				}else{
					
					mv= new ModelAndView("main_menu", "message", "not success");
				}
			
		} catch (Exception e) {			
			e.printStackTrace();
		}		
		
		return mv;
	}
	
	
	
	private boolean isValidUserCredential(String emailId, String password) {
		boolean flag=false;
		System.out.println("AAAAA");
		try {
			
			boolean b= service.findUser(emailId, password);
			if(b) {
				flag=true;
			}else {
				flag=false;	}
		}catch(LoginException e) {
			System.err.println(e.getMessage());
			
		}
		
		return flag;
	}
	
	private boolean isValidAdminCredential(String emailId, String password) {
		boolean flag=false;
		try {
			
			boolean b= service.findAdmin(emailId, password);
			if(b) {
				flag=true;
			}else {
				flag=false;	}
		}catch(LoginException e) {
			System.err.println(e.getMessage());
			
		}
		
		return flag;
	}
	
	private boolean isValidMerchantCredential(String emailId, String password) {
		boolean flag=false;
		try {
			
			boolean b= service.findMerchant(emailId, password);
			if(b) {
				flag=true;
			}else {
				flag=false;	}
		}catch(LoginException e) {
			System.err.println(e.getMessage());
			
		}
		
		return flag;
	}
	
	
	
}
				
	