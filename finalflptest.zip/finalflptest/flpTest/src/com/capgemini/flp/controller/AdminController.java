package com.capgemini.flp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.flp.dto.Customer;
import com.capgemini.flp.dto.Merchant_Product;
import com.capgemini.flp.dto.Merchant;
import com.capgemini.flp.exception.AllException;
import com.capgemini.flp.service.IAdminService;

@Controller
@RequestMapping(value="/admin")
public class AdminController {
	@Autowired
	IAdminService service;
	
	@RequestMapping ("/adminpage")
	public ModelAndView home(@RequestParam(value="emailId") String emailId){
		System.out.println("admincontroller");
		 	return new ModelAndView("adminhome","abc","abc");
	}
	@RequestMapping ("/merchant")
	public ModelAndView merchant(){
		try {List<Merchant> merchantList=service.getAllMerchantDetails();
		if(merchantList.size()!=0) {				
			return new ModelAndView("all_merchants","merchantList",merchantList);
		}else {
			return new ModelAndView("cust_status","message","No customers in database");
		}
	}catch(AllException e) {
		e.printStackTrace();
		return new ModelAndView("status","message",e.getMessage());
	}

		
	}
	@RequestMapping ("/customer")
	public ModelAndView customer(){
		try {
			List<Customer> customerList=service.getAllCustomerDetails();
			if(customerList.size()!=0) {				
				return new ModelAndView("all_customers","customerList",customerList);
			}else {
				return new ModelAndView("cust_status","message","No customers in database");
			}
		}catch(AllException e) {
			e.printStackTrace();
			return new ModelAndView("status","message",e.getMessage());
		}
	}
		
		
		
	
	
	@RequestMapping ("/product")
	public ModelAndView product(){
		try {
			List<Merchant_Product> productList=service.getAllProductDetails();
			System.out.println("good");
			System.out.println(productList.size());
			if(productList.size()!=0) {				
				return new ModelAndView("products","productList",productList);
			}else {
				return new ModelAndView("products","productList",productList);
			}
		}catch(AllException e) {
			e.printStackTrace();
			return new ModelAndView("status","message",e.getMessage());
		}
		}
	}
	

