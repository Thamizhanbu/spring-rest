package com.capgemini.flp.service;

import java.util.List;

import com.capgemini.flp.dto.Merchant_Product;
import com.capgemini.flp.exception.RevenueException;
import com.capgemini.flp.model.Revenue;


public interface IRevenueService {
	/*public List<Revenue> getBusinessdetails();*/
	public Merchant_Product findProductSold(String merchant_email_Id);

	public Revenue findRevenue(String email);
	
	//public Double findTotalRevenue();
	
	
	
	
}
