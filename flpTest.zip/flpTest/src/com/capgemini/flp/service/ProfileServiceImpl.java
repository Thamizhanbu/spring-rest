package com.capgemini.flp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;




import com.capgemini.flp.dao.IProfileDao;
import com.capgemini.flp.dto.Admin;
import com.capgemini.flp.dto.Customer;
import com.capgemini.flp.dto.Merchant;
import com.capgemini.flp.exception.IMerchantProfileException;

@javax.transaction.Transactional
@Service
public class ProfileServiceImpl implements IProfileService {
	
	@Autowired
	IProfileDao products;

	@Override
	public List<Admin> getProducts() throws IMerchantProfileException {
		return products.getProducts();
	}

	@Override
	public List<Admin> getProductsBasedOnCategory(String name) throws IMerchantProfileException {
		
		return products.getProductsBasedOnCategory(name);
	}

	@Override
	public String updateCustomer(Customer c) throws IMerchantProfileException {
		// TODO Auto-generated method stub
		return products.updateCustomer(c);
	}

	@Override
	public String updateMerchant(Merchant m,String emailId) throws IMerchantProfileException {
		// TODO Auto-generated method stub
		return products.updateMerchant(m,emailId);
	}

}
