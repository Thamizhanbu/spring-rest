package com.capgemini.flp.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.flp.dto.Feedback;
import com.capgemini.flp.dto.Merchant_Product;
import com.capgemini.flp.exception.ProductException;


@Repository
public class ProductDaoImpl implements IProductDao {

	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public List<Merchant_Product> getProducts() throws ProductException {
		try{
			TypedQuery<Merchant_Product> query=entityManager.createQuery("from Merchant_Product",Merchant_Product.class);
			return query.getResultList();
			}catch(Exception e){
				throw new ProductException(e.getMessage());
			}
	}

	@Override
	public List<Merchant_Product> getElectronicProducts() throws ProductException {
		try{
			TypedQuery<Merchant_Product> query=entityManager.createQuery("select admin from Merchant_Product admin where admin.productCategory='Electronics'",Merchant_Product.class);
			return query.getResultList();
			}catch(Exception e){
				throw new ProductException(e.getMessage());
			}
	}

	@Override
	public List<Merchant_Product> getFashionProducts() throws ProductException {
		try{
			TypedQuery<Merchant_Product> query=entityManager.createQuery("select admin from Merchant_Product admin where admin.productCategory='Fashion' or admin.productCategory='fashion' ",Merchant_Product.class);
			return query.getResultList();
			}catch(Exception e){
				throw new ProductException(e.getMessage());
			}
	}

	@Override
	public List<Merchant_Product> getFurnitureProducts() throws ProductException {
		try{
			TypedQuery<Merchant_Product> query=entityManager.createQuery("select admin from Merchant_Product admin where admin.productCategory='Furniture' or admin.productCategory='furniture' ",Merchant_Product.class);
			return query.getResultList();
			}catch(Exception e){
				throw new ProductException(e.getMessage());
			}
	}

	@Override
	public List<Merchant_Product> getSportsBooksAndMoreProducts() throws ProductException {
		try{
			TypedQuery<Merchant_Product> query=entityManager.createQuery("select admin from Merchant_Product admin where admin.productCategory='sportsbooksandmore' ",Merchant_Product.class);
			System.out.println("jdhygfi");
			return query.getResultList();
			}catch(Exception e){
				throw new ProductException(e.getMessage());
			}
	}

	@Override
	public Merchant_Product getProduct(String product) throws ProductException {
		try{
			TypedQuery<Merchant_Product> query=entityManager.createQuery("select admin from Merchant_Product admin where admin.productName='"+product+"'",Merchant_Product.class);
			System.out.println(query);
			return query.getSingleResult();
			}catch(Exception e){
				throw new ProductException(e.getMessage());
			}
	}
	
	


	@Override
	public List<Merchant_Product> getProductsAsc(String name,int asc) throws ProductException {
	
		try
		{
			TypedQuery<Merchant_Product> list;
		if(asc==1)
		{
			list = entityManager.createQuery("select admin from Merchant_Product admin where admin.productCategory='"+name+"' order by admin.productPrice",Merchant_Product.class);	
		}
		else if(asc==2)
		{
			
			list = entityManager.createQuery("select admin from Merchant_Product admin where admin.productCategory='"+name+"' order by admin.productPrice DESC",Merchant_Product.class);	
					
		}
		else
		{
			list = entityManager.createQuery("select admin from Merchant_Product admin where admin.productCategory='"+name+"' order by admin.numberOfProductSold DESC",Merchant_Product.class);
		}
		
		return list.getResultList();		
		}catch(Exception e){
			throw new ProductException(e.getMessage());
		}
			
	}

	@Override
	public List<Merchant_Product> getProductDesc(String category) throws ProductException {
          
		try{
			TypedQuery<Merchant_Product> query=entityManager.createQuery("select admin from Merchant_Product admin where admin.productCategory='"+category+"' order by admin.productPrice DESC",Merchant_Product.class);
			return query.getResultList();
			}catch(Exception e){
				throw new ProductException(e.getMessage());
			}
	}

	@Override
	public Merchant_Product getProductDetails(int id) throws ProductException {
		try{
			return entityManager.find(Merchant_Product.class, id);
			}catch(Exception e){
				throw new ProductException(e.getMessage());
			}
	}

	@Override
	public Merchant_Product getInvoice(int productid, int orderid)
			throws ProductException {
		Merchant_Product a=entityManager.find(Merchant_Product.class,productid);
		//entityManager.find(Merchant_Product.class, productid);
		return a;
	}

	@Override
	public List<Merchant_Product> getBestSelling(String category) throws ProductException {
		try{
			TypedQuery<Merchant_Product> query=entityManager.createQuery("select admin from Merchant_Product admin where admin.productCategory='"+category+"' order by admin.numberOfProductSold DESC",Merchant_Product.class);
			return query.getResultList();
			}catch(Exception e){
				throw new ProductException(e.getMessage());
			}
	}

	@Override
	public List<Merchant_Product> getSimilarProductsByCategory(String productCategory)
			throws ProductException {
		try {
			 TypedQuery <Merchant_Product> query=entityManager.createQuery("select admin from Merchant_Product admin where admin.productCategory = '"+productCategory+"'  order by admin.numberOfProductSold DESC",Merchant_Product.class);
				return query.getResultList(); 
			   } catch(PersistenceException e)
	            {
		           throw new ProductException(e.getMessage());
	            } 
		        
	
	}
	
	

	
	//Similar Products of same Name
	@Override
	public List<Merchant_Product> getSimilarProductsByName(String productName) throws ProductException 
	 {
		try 
		{
			TypedQuery <Merchant_Product> query=entityManager.createQuery("select admin from Merchant_Product admin where admin.productName = '"+productName+"' order by admin.numberOfProductSold DESC" ,Merchant_Product.class);
			return query.getResultList(); 
			 } catch(PersistenceException e)
	            {
		           throw new ProductException(e.getMessage());
	            } 
		        
	 }

	@Override
	public List<Feedback> getFeedbacks(int productId) throws ProductException {
		
		TypedQuery<Feedback> query=entityManager.createQuery("select feedback from Feedback feedback where feedback.product_Id='"+productId+"'",Feedback.class);
		
		System.out.println(query.getResultList());
	
		return query.getResultList();
	}
	
}
