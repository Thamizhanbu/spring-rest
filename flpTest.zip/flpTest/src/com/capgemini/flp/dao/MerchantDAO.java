package com.capgemini.flp.dao;

import org.springframework.stereotype.Repository;

@Repository
public interface MerchantDAO /*extends JpaRepository<Merchant, Integer>*/{
	
	void removeMerchantProducts(String emailId);
}
