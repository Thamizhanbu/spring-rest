package com.capgemini.flp.dao;

import javax.persistence.EntityManager; 
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.capgemini.flp.dto.Merchant;


@Repository
public class MerchantDaoImpl implements MerchantDAO{

	@PersistenceContext
	EntityManager em;
	
	@Override
	public void removeMerchantProducts(String emailId) {
		// TODO Auto-generated method stub
		Merchant merchant=em.find(Merchant.class,emailId);
		em.remove(merchant);
		
	}

	/*	@Query("select m from Merchants m where m.emailId=?1 ")
	Merchant findMerchant(String emailId);
	
	
	@Query("delete from Merchants m where m.emailId = ?1")
	void deleteMerchant(String emailId);
*/
	
}
