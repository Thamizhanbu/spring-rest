package com.capgemini.flp.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.capgemini.flp.dto.Admin;
import com.capgemini.flp.dto.Customer;
import com.capgemini.flp.dto.Merchant;
import com.capgemini.flp.exception.SignUpException;

@Repository
public class SignUpDao implements IntSignUpDao
{
	@Autowired
	@PersistenceContext
	private EntityManager entityManager;

	
	//Customer login
	@Override
	public boolean addCustomer(Customer customer) throws SignUpException {
		try
		{
			entityManager.persist(customer);
			return true;
		}catch(PersistenceException e) {
			throw new SignUpException(e.getMessage());
		}		
	}
  
	
	//Admin login
	@Override
	public boolean addAdmin(Admin admin) throws SignUpException {
		try {
			entityManager.persist(admin);
			return true;
		}catch(PersistenceException e) {
			throw new SignUpException(e.getMessage());
		}		
	}

	
	// Merchant login
	
	@Override
	public boolean addMerchant(Merchant merchant) throws SignUpException {
		try
		{
			entityManager.persist(merchant);
			return true;
		}catch(PersistenceException e) {
			throw new SignUpException(e.getMessage());
		}	
	
	}

	/*@Override
	public void Encrypt(String password, String email)throws CapstoreException {
		try{
		int s = 4; 
		
	    cap.setEmail(email);
	   
		String result= new String(); 
		
		  
	        for (int i=0; i<password.length(); i++) 
	        {
	        	 char ch = (char)(((int)password.charAt(i)+s));
	        	 String ps= Character.toString(ch);
	        	 result = result.concat(ps);
	        
	        } 
	        cap.setPassword(result);
	        entityManager.persist(cap);
			
	}catch(Exception e){
	
		throw new CapstoreException(e.getMessage());
		
	}
	
	*/
		@Override
	public String forget(String email)throws SignUpException {
		try{
		Merchant m=new Merchant();
		String pwd = null;
		String result=new String();
/*		int s = 4;*/
		m =entityManager.find(Merchant.class, email);
		
		if(m.getEmailId().equals(email)){
			result=m.getPassword();
/*			for (int i=0; i<m.getPassword().length(); i++) 
	        {
	        	 char ch = (char)(((int)m.getPassword().charAt(i)-s));
	        	 String ps= Character.toString(ch);
	        	 result = result.concat(ps);
	        
	        } */
			pwd = ("your password is  "+ "...... "+ result+" ......." + "  will be sent to your emailId "+email);
			return pwd;
		}else{
			throw new SignUpException();
		}	
		}catch(Exception e){
			throw new SignUpException(e.getMessage());
			
		}
	}

	
	
	
}


