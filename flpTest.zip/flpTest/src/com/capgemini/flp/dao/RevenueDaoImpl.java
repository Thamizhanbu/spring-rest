package com.capgemini.flp.dao;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.flp.dto.Merchant_Product;
import com.capgemini.flp.model.Revenue;


@Repository
@Transactional

public class RevenueDaoImpl implements IRevenueDao{
	@PersistenceContext
	EntityManager em;
	Revenue rev = new Revenue();
	Merchant_Product m=new Merchant_Product(); 
	
	
	public Merchant_Product findProductSold(String merchant_email_Id) {		
		 TypedQuery<Merchant_Product> query=em.createQuery("select m from Merchant_Product m where m.merchantEmailId=?",Merchant_Product.class);
			query.setParameter(1,merchant_email_Id);
			m = query.getSingleResult();
			double rev1= (double)m.getNumberOfProductSold() * m.getSellingAmount();
			rev.setRevenue(rev1);
			if(m.getSellingAmount()>m.getProductPrice())
			{
			double pro=(((m.getSellingAmount()-m.getProductPrice())/m.getProductPrice())*100);
			rev.setProfit(pro);
			}
			else
			{
				double loss=(((m.getProductPrice()-m.getSellingAmount())/m.getProductPrice())*100);
				rev.setLoss(loss);
			}
			em.persist(m);
			return m;	
	
	}


	@Override
	public Revenue findRevenue(String email) {
		TypedQuery<Merchant_Product> query=em.createQuery("select m from Merchant_Product m where m.merchantEmailId=?",Merchant_Product.class);
		query.setParameter(1,email);
		m = query.getSingleResult();
		double rev1= (double)m.getNumberOfProductSold() * m.getSellingAmount();
		rev.setRevenue(rev1);
		if(m.getSellingAmount()>m.getProductPrice())
		{
		double pro=(((m.getSellingAmount()-m.getProductPrice())/m.getProductPrice())*100);
		rev.setProfit(pro);
		}
		else
		{
			double loss=(((m.getProductPrice()-m.getSellingAmount())/m.getProductPrice())*100);
			rev.setLoss(loss);
		}
		em.persist(m);
		return rev;	
	}}

