package com.capgemini.flp.dao;

import java.util.List;

import com.capgemini.flp.dto.Feedback;
import com.capgemini.flp.dto.Merchant_Product;
import com.capgemini.flp.exception.ProductException;


public interface IProductDao {
	
	public List<Merchant_Product> getProducts() throws ProductException;

	public List<Merchant_Product> getElectronicProducts() throws ProductException;
	
	public List<Merchant_Product> getFashionProducts() throws ProductException;
	
	public List<Merchant_Product> getFurnitureProducts() throws ProductException;
	
	public List<Merchant_Product> getSportsBooksAndMoreProducts() throws ProductException;
	
	public Merchant_Product getProduct(String product) throws ProductException ;

	public List<Merchant_Product> getProductsAsc(String name,int asc) throws ProductException;

	public List<Merchant_Product> getProductDesc(String category) throws ProductException;

	public Merchant_Product getProductDetails(int id) throws ProductException;
	
	public Merchant_Product getInvoice(int productid, int orderid)throws ProductException;

	public List<Merchant_Product> getBestSelling(String category)throws ProductException;

	public List<Merchant_Product> getSimilarProductsByCategory(String productCategory) throws ProductException;

	public List<Merchant_Product> getSimilarProductsByName(String productName)throws ProductException;

	public List<Feedback> getFeedbacks(int productId)throws ProductException;

	
}
