package com.capgemini.flp.dao;

import java.util.List;

import com.capgemini.flp.dto.Merchant_Product;
import com.capgemini.flp.exception.RevenueException;
import com.capgemini.flp.model.Revenue;

public interface IRevenueDao {

	public Merchant_Product findProductSold(String merchant_email_Id);

	public Revenue findRevenue(String email);

	//Double findTotalRevenue();

	

}
