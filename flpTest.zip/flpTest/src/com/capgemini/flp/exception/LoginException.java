package com.capgemini.flp.exception;

public class LoginException extends Exception{
	String message;
	public LoginException() {
		// TODO Auto-generated constructor stub
	}
	public LoginException(String message) {
		super();
		this.message = message;
	}
	

	@Override
	public String getMessage() {
		return this.message+"\n"+super.getMessage();
	}

	@Override
	public String toString() {
		return super.toString();
	}
	

}
