package com.capgemini.flp.exception;

public class MerchantProductException extends Exception {

	private static final long serialVersionUID = 1L;

	public MerchantProductException(String msg) {
		super(msg);
	}
}
